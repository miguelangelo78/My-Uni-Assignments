/*
 * linked_list.c
 *
 *  Created on: 28/02/2017
 *      Author: Miguel
 */


