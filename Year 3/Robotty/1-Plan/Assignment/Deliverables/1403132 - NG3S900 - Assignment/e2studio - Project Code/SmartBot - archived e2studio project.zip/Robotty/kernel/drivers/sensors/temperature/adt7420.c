/*
 * adt7420.c
 *
 *  Created on: 13/03/2017
 *      Author: Miguel
 */


