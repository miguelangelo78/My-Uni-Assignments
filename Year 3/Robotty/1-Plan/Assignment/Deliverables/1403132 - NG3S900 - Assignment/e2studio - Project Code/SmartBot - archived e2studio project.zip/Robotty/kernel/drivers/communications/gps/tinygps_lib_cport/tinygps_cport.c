/*
 * tinygps_cport.c
 *
 *  Created on: 24/02/2017
 *      Author: Miguel
 */

#include "../../../../../kernel/drivers/communications/gps/tinygps_lib_cport/tinygps.h"

/* Reference: https://github.com/acassis/tinygps/blob/64e29d9158f318ff8deae1d94a680e5afbf57854/tinygps.c */
