/*
 * utils.h
 *
 *  Created on: 06/03/2017
 *      Author: Miguel
 */

#ifndef LIBS_UTILS_H_
#define LIBS_UTILS_H_

long map(long x, long in_min, long in_max, long out_min, long out_max);
float mapfloat(float x, float in_min, float in_max, float out_min, float out_max);

#endif /* LIBS_UTILS_H_ */
