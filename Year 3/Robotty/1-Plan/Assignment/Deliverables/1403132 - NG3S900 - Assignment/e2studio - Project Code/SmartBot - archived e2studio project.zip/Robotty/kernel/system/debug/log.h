/*
 * log.h
 *
 *  Created on: 25/02/2017
 *      Author: Miguel
 */

#ifndef KERNEL_DEBUG_LOG_H_
#define KERNEL_DEBUG_LOG_H_



#endif /* KERNEL_DEBUG_LOG_H_ */
