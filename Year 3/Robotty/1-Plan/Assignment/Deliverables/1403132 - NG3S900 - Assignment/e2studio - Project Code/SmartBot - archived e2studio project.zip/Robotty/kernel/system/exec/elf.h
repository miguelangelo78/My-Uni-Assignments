/*
 * elf.h
 *
 *  Created on: 25/02/2017
 *      Author: Miguel
 */

#ifndef KERNEL_EXEC_ELF_H_
#define KERNEL_EXEC_ELF_H_



#endif /* KERNEL_EXEC_ELF_H_ */
