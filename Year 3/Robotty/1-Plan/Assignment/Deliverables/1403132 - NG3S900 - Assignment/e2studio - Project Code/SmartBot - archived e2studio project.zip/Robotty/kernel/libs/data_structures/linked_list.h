/*
 * linked_list.h
 *
 *  Created on: 28/02/2017
 *      Author: Miguel
 */

#ifndef LIBS_DATA_STRUCTURES_LINKED_LIST_H_
#define LIBS_DATA_STRUCTURES_LINKED_LIST_H_



#endif /* LIBS_DATA_STRUCTURES_LINKED_LIST_H_ */
