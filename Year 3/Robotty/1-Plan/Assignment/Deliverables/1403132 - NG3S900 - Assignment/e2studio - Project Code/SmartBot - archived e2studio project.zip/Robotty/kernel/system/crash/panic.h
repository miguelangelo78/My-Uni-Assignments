/*
 * panic.h
 *
 *  Created on: 25/02/2017
 *      Author: Miguel
 */

#ifndef KERNEL_CRASH_PANIC_H_
#define KERNEL_CRASH_PANIC_H_



#endif /* KERNEL_CRASH_PANIC_H_ */
