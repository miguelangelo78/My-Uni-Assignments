/*
 * adt7420.h
 *
 *  Created on: 13/03/2017
 *      Author: Miguel
 */

#ifndef DRIVERS_SENSORS_TEMPERATURE_ADT7420_H_
#define DRIVERS_SENSORS_TEMPERATURE_ADT7420_H_



#endif /* DRIVERS_SENSORS_TEMPERATURE_ADT7420_H_ */
